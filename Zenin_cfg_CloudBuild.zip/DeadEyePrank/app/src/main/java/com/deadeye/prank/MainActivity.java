package com.deadeye.prank;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

public class MainActivity extends Activity {
    private static final String PASSWORD = "666";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView image = new ImageView(this);
        try {
            image.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("prank.jpg")));
        } catch (Exception ignored) { }
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(image, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(20), dp(18), dp(20), dp(22));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xDD090909);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xFFB00020);
        panel.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("NO MERCY");
        title.setTextColor(0xFFFF3030);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Введи пароль, чтобы закрыть приложение");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8);
        panel.addView(subtitle, sp);

        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        password.setHint("Пароль");
        password.setHintTextColor(0xFFAAAAAA);
        password.setTextColor(Color.WHITE);
        password.setTextSize(18);
        password.setGravity(Gravity.CENTER);
        password.setPadding(dp(12), 0, dp(12), 0);
        password.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFF3030));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(52));
        ep.topMargin = dp(14);
        panel.addView(password, ep);

        Button close = new Button(this);
        close.setText("РАЗБЛОКИРОВАТЬ");
        close.setTextColor(Color.WHITE);
        close.setAllCaps(false);
        close.setTextSize(16);
        close.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB00020));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50));
        bp.topMargin = dp(10);
        panel.addView(close, bp);

        close.setOnClickListener(v -> {
            if (PASSWORD.equals(password.getText().toString())) {
                finish();
            } else {
                password.setError("Неверный пароль");
                password.setText("");
                Toast.makeText(this, "Неверный пароль", Toast.LENGTH_SHORT).show();
            }
        });

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        pp.setMargins(dp(16), dp(16), dp(16), dp(28));
        root.addView(panel, pp);
        setContentView(root);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
