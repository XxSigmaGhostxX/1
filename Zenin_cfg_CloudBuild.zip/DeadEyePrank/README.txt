Zenin cfg — Android Studio project

Что делает приложение:
- Показывает приложенную картинку на весь экран.
- Для закрытия через кнопку приложения нужно ввести пароль 666.
- Не запрашивает разрешений, не блокирует телефон и не препятствует системному выходу на главный экран.

Как собрать APK на Windows 10:
1. Установи Android Studio с официального сайта developer.android.com/studio.
2. Распакуй архив Zenin_cfg_Project.zip.
3. В Android Studio выбери Open и укажи папку ZeninCfg.
4. Дождись окончания Gradle Sync и установки Android SDK Platform 35 (если Android Studio предложит).
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Пароль для закрытия внутри приложения: 666
